from flask import Blueprint, render_template

# Blueprint를 사용하여 auth를 생성
auth = Blueprint(
    "auth",
    __name__,
    static_folder="static",
    template_folder="templates",
)


# 테스트를 위한 엔드포인트
@auth.route("/")
def index():
    return render_template("auth/index.html")
